﻿namespace TimeTableManagmentSystem.Views
{
    partial class test
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.panel1 = new System.Windows.Forms.Panel();
            this.duartionUpAndDown = new System.Windows.Forms.NumericUpDown();
            this.label6 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.selectSubGroupCombobox = new System.Windows.Forms.ComboBox();
            this.noOfStudentUpAndDown = new System.Windows.Forms.NumericUpDown();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.selectGroupcombobox = new System.Windows.Forms.ComboBox();
            this.label3 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.selectTagCombobox = new System.Windows.Forms.ComboBox();
            this.label2 = new System.Windows.Forms.Label();
            this.selectLecturerLabel = new System.Windows.Forms.Label();
            this.selectLecturerCombobox = new System.Windows.Forms.ComboBox();
            this.sessionSaveBtn = new System.Windows.Forms.Button();
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.duartionUpAndDown)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.noOfStudentUpAndDown)).BeginInit();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.White;
            this.panel1.Controls.Add(this.duartionUpAndDown);
            this.panel1.Controls.Add(this.label6);
            this.panel1.Controls.Add(this.label7);
            this.panel1.Controls.Add(this.selectSubGroupCombobox);
            this.panel1.Controls.Add(this.noOfStudentUpAndDown);
            this.panel1.Controls.Add(this.label4);
            this.panel1.Controls.Add(this.label5);
            this.panel1.Controls.Add(this.selectGroupcombobox);
            this.panel1.Controls.Add(this.label3);
            this.panel1.Controls.Add(this.label1);
            this.panel1.Controls.Add(this.selectTagCombobox);
            this.panel1.Controls.Add(this.label2);
            this.panel1.Controls.Add(this.selectLecturerLabel);
            this.panel1.Controls.Add(this.selectLecturerCombobox);
            this.panel1.Controls.Add(this.sessionSaveBtn);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel1.Location = new System.Drawing.Point(0, 0);
            this.panel1.Margin = new System.Windows.Forms.Padding(20);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(800, 450);
            this.panel1.TabIndex = 24;
            // 
            // duartionUpAndDown
            // 
            this.duartionUpAndDown.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.duartionUpAndDown.Location = new System.Drawing.Point(742, 283);
            this.duartionUpAndDown.Name = "duartionUpAndDown";
            this.duartionUpAndDown.Size = new System.Drawing.Size(303, 30);
            this.duartionUpAndDown.TabIndex = 68;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.Location = new System.Drawing.Point(578, 285);
            this.label6.Name = "label6";
            this.label6.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.label6.Size = new System.Drawing.Size(85, 25);
            this.label6.TabIndex = 67;
            this.label6.Text = "Duration";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.Location = new System.Drawing.Point(46, 285);
            this.label7.Name = "label7";
            this.label7.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.label7.Size = new System.Drawing.Size(167, 25);
            this.label7.TabIndex = 65;
            this.label7.Text = "Select Sub Group";
            // 
            // selectSubGroupCombobox
            // 
            this.selectSubGroupCombobox.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.selectSubGroupCombobox.FormattingEnabled = true;
            this.selectSubGroupCombobox.Location = new System.Drawing.Point(225, 282);
            this.selectSubGroupCombobox.Name = "selectSubGroupCombobox";
            this.selectSubGroupCombobox.Size = new System.Drawing.Size(303, 33);
            this.selectSubGroupCombobox.TabIndex = 66;
            // 
            // noOfStudentUpAndDown
            // 
            this.noOfStudentUpAndDown.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.noOfStudentUpAndDown.Location = new System.Drawing.Point(742, 200);
            this.noOfStudentUpAndDown.Name = "noOfStudentUpAndDown";
            this.noOfStudentUpAndDown.Size = new System.Drawing.Size(303, 30);
            this.noOfStudentUpAndDown.TabIndex = 64;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(578, 202);
            this.label4.Name = "label4";
            this.label4.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.label4.Size = new System.Drawing.Size(141, 25);
            this.label4.TabIndex = 62;
            this.label4.Text = "No of Students";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(46, 202);
            this.label5.Name = "label5";
            this.label5.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.label5.Size = new System.Drawing.Size(126, 25);
            this.label5.TabIndex = 60;
            this.label5.Text = "Select Group";
            // 
            // selectGroupcombobox
            // 
            this.selectGroupcombobox.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.selectGroupcombobox.FormattingEnabled = true;
            this.selectGroupcombobox.Location = new System.Drawing.Point(225, 199);
            this.selectGroupcombobox.Name = "selectGroupcombobox";
            this.selectGroupcombobox.Size = new System.Drawing.Size(303, 33);
            this.selectGroupcombobox.TabIndex = 61;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(46, 137);
            this.label3.Name = "label3";
            this.label3.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.label3.Size = new System.Drawing.Size(262, 25);
            this.label3.TabIndex = 59;
            this.label3.Text = "Select Group And Subject";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(46, 14);
            this.label1.Name = "label1";
            this.label1.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.label1.Size = new System.Drawing.Size(269, 25);
            this.label1.TabIndex = 58;
            this.label1.Text = "Select Lecturers And Tags";
            // 
            // selectTagCombobox
            // 
            this.selectTagCombobox.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.selectTagCombobox.FormattingEnabled = true;
            this.selectTagCombobox.Location = new System.Drawing.Point(742, 71);
            this.selectTagCombobox.Name = "selectTagCombobox";
            this.selectTagCombobox.Size = new System.Drawing.Size(303, 33);
            this.selectTagCombobox.TabIndex = 57;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(578, 74);
            this.label2.Name = "label2";
            this.label2.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.label2.Size = new System.Drawing.Size(107, 25);
            this.label2.TabIndex = 55;
            this.label2.Text = "Select Tag";
            // 
            // selectLecturerLabel
            // 
            this.selectLecturerLabel.AutoSize = true;
            this.selectLecturerLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.selectLecturerLabel.Location = new System.Drawing.Point(46, 74);
            this.selectLecturerLabel.Name = "selectLecturerLabel";
            this.selectLecturerLabel.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.selectLecturerLabel.Size = new System.Drawing.Size(143, 25);
            this.selectLecturerLabel.TabIndex = 16;
            this.selectLecturerLabel.Text = "Select Lecturer";
            // 
            // selectLecturerCombobox
            // 
            this.selectLecturerCombobox.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.selectLecturerCombobox.FormattingEnabled = true;
            this.selectLecturerCombobox.Location = new System.Drawing.Point(225, 71);
            this.selectLecturerCombobox.Name = "selectLecturerCombobox";
            this.selectLecturerCombobox.Size = new System.Drawing.Size(303, 33);
            this.selectLecturerCombobox.TabIndex = 18;
            // 
            // sessionSaveBtn
            // 
            this.sessionSaveBtn.BackColor = System.Drawing.Color.Blue;
            this.sessionSaveBtn.FlatAppearance.BorderColor = System.Drawing.Color.Red;
            this.sessionSaveBtn.FlatAppearance.BorderSize = 0;
            this.sessionSaveBtn.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.sessionSaveBtn.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.sessionSaveBtn.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.sessionSaveBtn.ForeColor = System.Drawing.Color.White;
            this.sessionSaveBtn.Location = new System.Drawing.Point(532, 367);
            this.sessionSaveBtn.Name = "sessionSaveBtn";
            this.sessionSaveBtn.Padding = new System.Windows.Forms.Padding(10);
            this.sessionSaveBtn.Size = new System.Drawing.Size(131, 53);
            this.sessionSaveBtn.TabIndex = 23;
            this.sessionSaveBtn.Text = "Save";
            this.sessionSaveBtn.UseVisualStyleBackColor = false;
            // 
            // test
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.panel1);
            this.Name = "test";
            this.Text = "test";
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.duartionUpAndDown)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.noOfStudentUpAndDown)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.NumericUpDown duartionUpAndDown;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.ComboBox selectSubGroupCombobox;
        private System.Windows.Forms.NumericUpDown noOfStudentUpAndDown;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.ComboBox selectGroupcombobox;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.ComboBox selectTagCombobox;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label selectLecturerLabel;
        private System.Windows.Forms.ComboBox selectLecturerCombobox;
        private System.Windows.Forms.Button sessionSaveBtn;
    }
}